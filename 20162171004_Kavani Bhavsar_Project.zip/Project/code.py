# import OpenCV library
import cv2

#CascadeClassifier object to detect faces
face_cascade = cv2.CascadeClassifier('D:\SEM - 6\IMPR\Project\haarcascade_frontalface_default.xml')

# Initialize the webcam
# setting the index of the camera to 0 to use the default camera
cap = cv2.VideoCapture(0)

# Start an infinite loop to capture frames from the camera and detect faces in them
while True:
    # Read a frame from the webcam
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame using the CascadeClassifier object
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    # Draw a rectangle around each face and count the number of faces
    count = 0
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        count += 1

    # Display the frame and the number of faces
    cv2.putText(frame, f"Faces: {count}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    cv2.imshow('frame', frame)

    # Exit if the user presses 'q' or clicks on the close button
    if cv2.waitKey(1) & 0xFF == ord('q') or cv2.getWindowProperty('frame', cv2.WND_PROP_VISIBLE) < 1:
        break

# Release the webcam and close the window
cap.release()
cv2.destroyAllWindows()
